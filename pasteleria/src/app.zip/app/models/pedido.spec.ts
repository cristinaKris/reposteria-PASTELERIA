import { Pedido } from './pedido';

describe('Pedido', () => {
  it('should create an instance', () => {
    expect(new Pedido()).toBeTruthy();
  });
});
