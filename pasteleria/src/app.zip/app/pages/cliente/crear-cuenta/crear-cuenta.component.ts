import { Component } from '@angular/core';

@Component({
  selector: 'app-crear-cuenta',
  imports: [],
  templateUrl: './crear-cuenta.component.html',
  styleUrl: './crear-cuenta.component.scss'
})
export class CrearCuentaComponent {

}